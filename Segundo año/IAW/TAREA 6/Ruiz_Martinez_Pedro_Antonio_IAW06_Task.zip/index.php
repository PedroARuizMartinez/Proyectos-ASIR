<html>
	<head>
    	<!--IAW06 By Pedro Antonio Ruiz Mart�nez -->
		<title>PEDRO'S FILMS</TITLE>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>

	<body>
		<h1>Welcome to Pedro's video library:</h1>
		<br><br>
		<h3>Please select one options:</h3>
		<br><br>
		<a href="list.php">Films list</a>
		<br><br>
		<a href="create.php">Create a new film</a>
		<br><br>
		<a href="delete.php">Delete film</a>
		
	</body>

</html>

