<html>
	<head>
    	<!--IAW06 By Pedro Antonio Ruiz Mart�nez -->
		<title> Pedro's Films </title>
	</head>
	<body>
		<h1>Delete users</h1>
        
		<FORM name = "form1" ACTION="delete_confirm.php" method = "post">
    		<p>Insert ID of the Film to be deleted: <INPUT TYPE="text" NAME="IDfilm" ID = "IDfilm" SIZE="3" MAXLENGTH="3"></p>
    		<input name="delete" type="submit" value="Delete">
		</FORM>
        
		<br><br><br>
        
		<a href = "index.php"> Home </a>
	</body>
</html>

