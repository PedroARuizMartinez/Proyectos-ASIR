<?php
// $HeadURL: https://joomgallery.org/svn/joomgallery/JG-2.0/JG/branches/ajax/components/com_joomgallery/views/vote/view.raw.php $
// $Id: view.raw.php 3665 2012-02-26 21:24:47Z chraneco $
/****************************************************************************************\
**   JoomGallery 2                                                                      **
**   By: JoomGallery::ProjectTeam                                                       **
**   Copyright (C) 2008 - 2012  JoomGallery::ProjectTeam                                **
**   Based on: JoomGallery 1.0.0 by JoomGallery::ProjectTeam                            **
**   Released under GNU GPL Public License                                              **
**   License: http://www.gnu.org/copyleft/gpl.html or have a look                       **
**   at administrator/components/com_joomgallery/LICENSE.TXT                            **
\****************************************************************************************/

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

/**
 * View class for selecting a name tag view
 *
 * @package JoomGallery
 * @since   2.1
 */
class JoomGalleryViewNametag extends JoomGalleryView
{
  // Nothing to do
}