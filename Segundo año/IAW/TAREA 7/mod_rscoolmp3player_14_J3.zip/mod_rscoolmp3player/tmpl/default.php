<?php
/**
 * RS-CoolMP3Player
 * 
 * @package - Joomla
 * @subpackage - Modules
 * @link - www.rswebsols.com
 * @license - GNU/GPL
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

echo  $rswsReturn;
?>